package ap;

public class Domicilio {
	private Integer id;
	private String calle;
	private String altura;
	private String pisoDtpo;
	private Integer idPersona; //apunta a la persona dueña de este domicilios
	
	//gettres y setters
	public Integer getIdPersona() {
		return idPersona;
	}
	public void setIdPersona(Integer idPersona) {
		this.idPersona = idPersona;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCalle() {
		return calle;
	}
	public void setCalle(String calle) {
		this.calle = calle;
	}
	public String getAltura() {
		return altura;
	}
	public void setAltura(String altura) {
		this.altura = altura;
	}
	public String getPisoDtpo() {
		return pisoDtpo;
	}
	public void setPisoDtpo(String pisoDtpo) {
		this.pisoDtpo = pisoDtpo;
	}
	

	//métodos
	public void mostrar() {
	}

	public void editar() {
	}
}
	
	
	


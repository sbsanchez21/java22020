package argProg;

import java.sql.Date;

public class Educacion {
	private Integer id;
	private String institucion;
	private String titulo;
	private Double promedio;
	private Date fechaIni;
	private Date fechaFin;
	
	public Educacion(Integer id, String institucion, String titulo, Double promedio, Date fechaIni, Date fechaFin) {
		super();
		this.id = id;
		this.institucion = institucion;
		this.titulo = titulo;
		this.promedio = promedio;
		this.fechaIni = fechaIni;
		this.fechaFin = fechaFin;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getInstitucion() {
		return institucion;
	}

	public void setInstitucion(String institucion) {
		this.institucion = institucion;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Double getPromedio() {
		return promedio;
	}

	public void setPromedio(Double promedio) {
		this.promedio = promedio;
	}

	public Date getFechaIni() {
		return fechaIni;
	}

	public void setFechaIni(Date fechaIni) {
		this.fechaIni = fechaIni;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	
	
	
	

}

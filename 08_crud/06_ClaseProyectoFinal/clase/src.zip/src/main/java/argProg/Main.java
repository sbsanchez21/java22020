package argProg;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Main {
	
	public static void main(String[] args) throws SQLException {
		//conectar a db, traer todas la personas
		ConexionDB conexionDB = new ConexionDB();
		Connection connection = conexionDB.establecerConexion();
		Statement statement = connection.createStatement();
		
		ResultSet rs = statement.executeQuery("SELECT * FROM persona");
		
		List<Persona> listPers = new ArrayList<Persona>();
		while (rs.next()) {
			Persona persona = new Persona(rs.getInt("id"), rs.getString("nombre"), rs.getString("apellido"), rs.getString("profesion"), rs.getString("acerca_De") );
			
			listPers.add(persona);
		}
		
		
	}

}

package argProg;

public class Domicilio {
	private Integer id;
	private String calle;
	private String altura;
	private String pisoDtpo;
	private Integer idPersona; //apunta a la persona dueña de este domicilios
	
	
	
	public Domicilio(Integer id, String calle, String altura, String pisoDtpo, Integer idPersona) {
		super();
		this.id = id;
		this.calle = calle;
		this.altura = altura;
		this.pisoDtpo = pisoDtpo;
		this.idPersona = idPersona;
	}
	
	//gettres y setters
	public Integer getIdPersona() {
		return idPersona;
	}
	public void setIdPersona(Integer idPersona) {
		this.idPersona = idPersona;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCalle() {
		return calle;
	}
	public void setCalle(String calle) {
		this.calle = calle;
	}
	public String getAltura() {
		return altura;
	}
	public void setAltura(String altura) {
		this.altura = altura;
	}
	public String getPisoDtpo() {
		return pisoDtpo;
	}
	public void setPisoDtpo(String pisoDtpo) {
		this.pisoDtpo = pisoDtpo;
	}
	

	//métodos
	public void mostrar() {
	}

	public void editar() {
	}
}
	
	
	


package argProg;

import java.util.List;

public class Persona {
	//atributos
	private Integer id;
	private String nombre;
	private String apellido;
	private String titulo;
	private String acercaDe;
//	private Blob fotoPerfil;
	private Domicilio domicilio;
	private List<Educacion> listEducacion;

	//constructor

	public Persona(Integer id, String nombre, String apellido, String titulo, String acercaDe, Domicilio domicilio,
			List<Educacion> listEducacion) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.titulo = titulo;
		this.acercaDe = acercaDe;
		this.domicilio=domicilio;
		this.listEducacion = listEducacion;
	}	
	
	//getters y setters
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		//TODO: verificar que el obj que invoca tenga permisos
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAcercaDe() {
		return acercaDe;
	}
	public void setAcercaDe(String acercaDe) {
		this.acercaDe = acercaDe;
	}
	
	
	
	
	public List<Educacion> getListEducacion() {
		return listEducacion;
	}

	public void setListEducacion(List<Educacion> listEducacion) {
		this.listEducacion = listEducacion;
	}
	
	
	

	public Domicilio getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(Domicilio domicilio) {
		this.domicilio = domicilio;
	}

	//métodos
	/**
	 * Modifica los datos del domicilio.
	 * 
	 * @return true si se upd correctamente, false si hubo un error
	 */
	public Boolean updDomicilio() {
		// TODO Auto-generated method stub

		return null;
	}
	
	
	private void addEducacion() {
		// TODO Auto-generated method stub

	}

}

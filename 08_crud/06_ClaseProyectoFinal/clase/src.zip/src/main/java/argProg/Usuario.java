package argProg;

import java.util.List;

public class Usuario extends Persona {
	private String nombre;
	private String password;

	public Usuario(Integer id, String nombre, String apellido, String titulo, String acercaDe, Domicilio domicilio,
			List<Educacion> listEducacion, String nombreUsu, String password) {
		super(id, nombre, apellido, titulo, acercaDe, domicilio, listEducacion);
		// TODO Auto-generated constructor stub
		this.nombre=nombreUsu;
		this.password=password;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
